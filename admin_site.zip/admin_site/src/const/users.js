export const users = [
    {
        name: "Michael",
        surname: "Hursey",
        level: "1"
    },
    {
        name: "Jose",
        surname: "San Martin",
        level: "9000"
    },
    {
        name: "Eric",
        surname: "Fu",
        level: "0"
    },
    {
        name: "Caleb",
        surname: "Chiang",
        level: "12"
    },
];