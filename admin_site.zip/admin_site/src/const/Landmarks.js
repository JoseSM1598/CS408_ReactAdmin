export const landmarks = [
    {
        name: "West Union",
        lat: 36.00103,
        long: -78.939225
    },
    {
        name: "Bostock Library",
        lat: 36.003152,
        long: -78.938324
    },
    {
        name: "Pitchforks",
        lat: 35.999206,
        long: -78.936716
    }


];