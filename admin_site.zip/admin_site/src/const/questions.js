export const questions = [
    {
        name: "Michael",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Eric",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "1 Hour Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },
    {
        name: "Caleb",
        time: "5 Hours Ago",
        content: "Is West Union currently packed?"
    },


];