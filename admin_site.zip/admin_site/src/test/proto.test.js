//This file is for tests on the protobuf requests/responses
jest.enableAutomock();

// import { exportAllDeclaration } from '@babel/types';
// import SpacesTab from '../Components/SpacesTab/SpacesTab';
// import TransactionsContainer from '../Components/TransactionsTab/TransactionsContainer';


test("GetAllTransactionsRequest", () =>{
    var test = 0;
    expect(test).not.toBeNull();
});

// test('Test Mapping Transactions to State in Transactions Container', () => {

// });

// test('Test SearchSpaceByNameRequest', () => {

// });


