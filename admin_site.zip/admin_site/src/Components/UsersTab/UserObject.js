//This represents an a user in the table
import React from 'react'


export default function UserObject(props){

    const [user, setUser] = useState(props.user)
    return (
        <tr>
            <td></td>
            <td></td>
            <td></td>
        </tr>
    );
}
